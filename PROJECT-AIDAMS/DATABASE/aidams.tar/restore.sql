--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.0
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE aidams;
--
-- Name: aidams; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE aidams WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE aidams OWNER TO postgres;

\connect aidams

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.access (
    acs_id integer NOT NULL,
    is_permitted boolean DEFAULT true,
    date_created date DEFAULT CURRENT_TIMESTAMP,
    date_updated date DEFAULT CURRENT_TIMESTAMP,
    bm_id integer NOT NULL,
    dv_id integer NOT NULL
);


ALTER TABLE public.access OWNER TO postgres;

--
-- Name: access_acs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.access ALTER COLUMN acs_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.access_acs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account (
    acc_id integer NOT NULL,
    acc_fname character varying(50) NOT NULL,
    acc_mname character varying(50) NOT NULL,
    acc_lname character varying(50) NOT NULL,
    acc_password character varying(50) NOT NULL,
    acc_profile bytea,
    acc_contact character varying(11) NOT NULL,
    acc_email character varying(50) NOT NULL,
    acc_type character varying(20) DEFAULT 'USER'::character varying,
    date_created date DEFAULT CURRENT_TIMESTAMP,
    date_updated date DEFAULT CURRENT_TIMESTAMP,
    acc_status character varying(20) DEFAULT 'ACTIVE'::character varying
);


ALTER TABLE public.account OWNER TO postgres;

--
-- Name: account_acc_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.account ALTER COLUMN acc_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.account_acc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: blc_member; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blc_member (
    bm_id integer NOT NULL,
    date_created date DEFAULT CURRENT_TIMESTAMP,
    date_updated date DEFAULT CURRENT_TIMESTAMP,
    acc_id integer NOT NULL,
    blc_id integer NOT NULL
);


ALTER TABLE public.blc_member OWNER TO postgres;

--
-- Name: blc_member_bm_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.blc_member ALTER COLUMN bm_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.blc_member_bm_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: bloc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bloc (
    blc_id integer NOT NULL,
    date_created date DEFAULT CURRENT_TIMESTAMP,
    date_updated date DEFAULT CURRENT_TIMESTAMP,
    acc_id integer
);


ALTER TABLE public.bloc OWNER TO postgres;

--
-- Name: bloc_blc_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.bloc ALTER COLUMN blc_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.bloc_blc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: device; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.device (
    dv_id integer NOT NULL,
    dv_name character varying(50) NOT NULL,
    dv_key integer NOT NULL,
    dv_password character varying(50) NOT NULL,
    dv_status character varying(20) NOT NULL,
    dv_auto_lock boolean DEFAULT true,
    date_created date DEFAULT CURRENT_TIMESTAMP,
    date_updated date DEFAULT CURRENT_TIMESTAMP,
    acc_id integer NOT NULL,
    dv_auto_lock_time integer DEFAULT 15,
    dv_curfew boolean DEFAULT true,
    dv_curfew_time time without time zone DEFAULT '11:00:00'::time without time zone
);


ALTER TABLE public.device OWNER TO postgres;

--
-- Name: device_dv_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.device ALTER COLUMN dv_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.device_dv_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.history (
    his_id integer NOT NULL,
    date_created date DEFAULT CURRENT_TIMESTAMP,
    date_updated date DEFAULT CURRENT_TIMESTAMP,
    acc_id integer NOT NULL,
    dv_id integer NOT NULL
);


ALTER TABLE public.history OWNER TO postgres;

--
-- Name: history_his_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.history ALTER COLUMN his_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.history_his_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification (
    ntf_id integer NOT NULL,
    ntf_type character varying(20) NOT NULL,
    ntf_message character varying(50) NOT NULL,
    date_created date DEFAULT CURRENT_TIMESTAMP,
    date_updated date DEFAULT CURRENT_TIMESTAMP,
    dv_id integer NOT NULL
);


ALTER TABLE public.notification OWNER TO postgres;

--
-- Name: notification_ntf_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.notification ALTER COLUMN ntf_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.notification_ntf_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: access; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.access (acs_id, is_permitted, date_created, date_updated, bm_id, dv_id) FROM stdin;
\.
COPY public.access (acs_id, is_permitted, date_created, date_updated, bm_id, dv_id) FROM '$$PATH$$/4855.dat';

--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account (acc_id, acc_fname, acc_mname, acc_lname, acc_password, acc_profile, acc_contact, acc_email, acc_type, date_created, date_updated, acc_status) FROM stdin;
\.
COPY public.account (acc_id, acc_fname, acc_mname, acc_lname, acc_password, acc_profile, acc_contact, acc_email, acc_type, date_created, date_updated, acc_status) FROM '$$PATH$$/4851.dat';

--
-- Data for Name: blc_member; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blc_member (bm_id, date_created, date_updated, acc_id, blc_id) FROM stdin;
\.
COPY public.blc_member (bm_id, date_created, date_updated, acc_id, blc_id) FROM '$$PATH$$/4854.dat';

--
-- Data for Name: bloc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bloc (blc_id, date_created, date_updated, acc_id) FROM stdin;
\.
COPY public.bloc (blc_id, date_created, date_updated, acc_id) FROM '$$PATH$$/4853.dat';

--
-- Data for Name: device; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.device (dv_id, dv_name, dv_key, dv_password, dv_status, dv_auto_lock, date_created, date_updated, acc_id, dv_auto_lock_time, dv_curfew, dv_curfew_time) FROM stdin;
\.
COPY public.device (dv_id, dv_name, dv_key, dv_password, dv_status, dv_auto_lock, date_created, date_updated, acc_id, dv_auto_lock_time, dv_curfew, dv_curfew_time) FROM '$$PATH$$/4852.dat';

--
-- Data for Name: history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.history (his_id, date_created, date_updated, acc_id, dv_id) FROM stdin;
\.
COPY public.history (his_id, date_created, date_updated, acc_id, dv_id) FROM '$$PATH$$/4856.dat';

--
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification (ntf_id, ntf_type, ntf_message, date_created, date_updated, dv_id) FROM stdin;
\.
COPY public.notification (ntf_id, ntf_type, ntf_message, date_created, date_updated, dv_id) FROM '$$PATH$$/4857.dat';

--
-- Name: access_acs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.access_acs_id_seq', 1, false);


--
-- Name: account_acc_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_acc_id_seq', 3, true);


--
-- Name: blc_member_bm_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blc_member_bm_id_seq', 1, false);


--
-- Name: bloc_blc_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bloc_blc_id_seq', 1, false);


--
-- Name: device_dv_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.device_dv_id_seq', 1, false);


--
-- Name: history_his_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.history_his_id_seq', 1, false);


--
-- Name: notification_ntf_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notification_ntf_id_seq', 1, false);


--
-- Name: access access_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access
    ADD CONSTRAINT access_pkey PRIMARY KEY (acs_id);


--
-- Name: account account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_pkey PRIMARY KEY (acc_id);


--
-- Name: blc_member blc_member_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blc_member
    ADD CONSTRAINT blc_member_pkey PRIMARY KEY (bm_id);


--
-- Name: bloc bloc_acc_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bloc
    ADD CONSTRAINT bloc_acc_id_key UNIQUE (acc_id);


--
-- Name: bloc bloc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bloc
    ADD CONSTRAINT bloc_pkey PRIMARY KEY (blc_id);


--
-- Name: device device_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.device
    ADD CONSTRAINT device_pkey PRIMARY KEY (dv_id);


--
-- Name: history history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history
    ADD CONSTRAINT history_pkey PRIMARY KEY (his_id);


--
-- Name: access access_bm_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access
    ADD CONSTRAINT access_bm_id_fkey FOREIGN KEY (bm_id) REFERENCES public.blc_member(bm_id) ON UPDATE CASCADE;


--
-- Name: access access_dv_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access
    ADD CONSTRAINT access_dv_id_fkey FOREIGN KEY (dv_id) REFERENCES public.device(dv_id) ON UPDATE CASCADE;


--
-- Name: blc_member blc_member_acc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blc_member
    ADD CONSTRAINT blc_member_acc_id_fkey FOREIGN KEY (acc_id) REFERENCES public.account(acc_id) ON UPDATE CASCADE;


--
-- Name: blc_member blc_member_blc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blc_member
    ADD CONSTRAINT blc_member_blc_id_fkey FOREIGN KEY (blc_id) REFERENCES public.bloc(blc_id) ON UPDATE CASCADE;


--
-- Name: bloc bloc_acc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bloc
    ADD CONSTRAINT bloc_acc_id_fkey FOREIGN KEY (acc_id) REFERENCES public.account(acc_id) ON UPDATE CASCADE;


--
-- Name: device device_acc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.device
    ADD CONSTRAINT device_acc_id_fkey FOREIGN KEY (acc_id) REFERENCES public.account(acc_id) ON UPDATE CASCADE;


--
-- Name: history history_acc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history
    ADD CONSTRAINT history_acc_id_fkey FOREIGN KEY (acc_id) REFERENCES public.account(acc_id) ON UPDATE CASCADE;


--
-- Name: history history_dv_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history
    ADD CONSTRAINT history_dv_id_fkey FOREIGN KEY (dv_id) REFERENCES public.device(dv_id) ON UPDATE CASCADE;


--
-- Name: notification notification_dv_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_dv_id_fkey FOREIGN KEY (dv_id) REFERENCES public.device(dv_id) ON UPDATE CASCADE;


--
-- PostgreSQL database dump complete
--

